package com.unir.exemploretrofit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.internal.RegisterListenerMethod;
import com.unir.exemploretrofit.api.CEPSvc;
import com.unir.exemploretrofit.banco_de_dados.SQLDB;
import com.unir.exemploretrofit.model.CEP;
import com.unir.exemploretrofit.model.MapasAct;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private Button botaoRecuperar;
    private TextView textoResultado;
    private EditText edtCEP;
    private Retrofit retrofit;
    private Button btnMostrar;
    private String endereco = null;
    private Button btnSalvar;
    SQLDB bd;
    private String cep1 = "";
    private Button btnLista;
    private Sensor acelerometro;
    private SensorManager sensorManager;
   private SensorEventListener sensorEventListener;
    private RegisterListenerMethod registerListener;

    //private Sensor acelerometro;
    //private SensorManager sensorManager;
    //private SensorEventListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botaoRecuperar = findViewById(R.id.btnRecuperar);
        textoResultado = findViewById(R.id.txtExibir);
        edtCEP = findViewById(R.id.edtCEP);
        btnMostrar = findViewById(R.id.btnMostrar);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnLista = findViewById(R.id.btnLista);
        String urlCep = "https://viacep.com.br/ws/";
        retrofit =  new Retrofit.Builder()
                .baseUrl(urlCep)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        botaoRecuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String resultado = recuperarCep();
            }
        });
        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MapasAct.class);
                Log.i("endereco",endereco);
                intent.putExtra("endereco",endereco);
                startActivity(intent);
            }
        });

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorEventListener = new SensorEventListener() {

            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                Log.i("val","teste: "+sensorEvent.values[0]);
                if(sensorEvent.values[0] > 10){
                    finish();
                }
            }
            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {
            }
        };



        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                cep1 = edtCEP.getText().toString();
                bd = new SQLDB(getApplicationContext());


                CEPSvc cepService = retrofit.create(CEPSvc.class);
                Call<CEP> call = cepService.recuperarCEP(cep1);
                call.enqueue(new Callback<CEP>() {
                    @Override
                    public void onResponse(Call<CEP> call, Response<CEP> response) {
                        if (response.isSuccessful()){

                            CEP cep = response.body();
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setMessage("O cep: " + cep1 + ", está situado em: \n\n" + cep.getLogradouro() +
                                    ", " + cep.getComplemento() + "\n" + cep.getBairro() + " - " + cep.getLocalidade() + "/" + cep.getUf());
                            builder.setCancelable(false);

                            builder.setNegativeButton("Salvar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    //Toast.makeText(MainActivity.this, "CEP salvo", Toast.LENGTH_SHORT).show();
                                    ContentValues cv = new ContentValues();
                                    cv.put("logradouro", cep.getLogradouro());
                                    cv.put("cep", cep.getCep());
                                    cv.put("bairro", cep.getBairro());
                                    cv.put("localidade", cep.getLocalidade());



                                    Long idd = bd.inserir(cep);

                                    if(idd>0){
                                        Toast.makeText(MainActivity.this, "salvo com sucesso", Toast.LENGTH_SHORT).show();
                                    }

                                    StringBuilder monta = new StringBuilder();
                                    monta.append(cep.getUf()).append("\n")
                                         .append(cep.getCep()).append("\n")
                                         .append(cep.getLocalidade()).append("\n")
                                         .append(cep.getBairro()).append("\n")
                                         .append(cep.getComplemento());


                                    Log.i("val","vll: "+idd+" \n "+monta.toString());
                                }
                            });
                            builder.setNeutralButton("OK", null);
                            builder.show();

                            edtCEP.setText("");
                        } else{
                            Toast.makeText(MainActivity.this, "CEP não encontrado", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<CEP> call, Throwable t) {

                    }
                });

                //cv.put("logradouro",.getLog);
            }
        });
        btnLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, Lista.class);
                //Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //sensorManager.registerListener(MainActivity.this, acelerometro, SensorManager.SENSOR_DELAY_NORMAL);
        //sensorManager.registerListener(MainActivity.this, acelerometro, SensorManager.SENSOR_DELAY_NORMAL);
        //sensorManager.registerListener(MainActivity.this, acelerometro, SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    protected void onPause() {
        super.onPause();
        //sensorManager.unregisterListener(this);
        //sensorManager.unregisterListener();
    }





    /*@Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.values[0] > 17.8) {

            //Toast.makeText(this, "Fechando App...", Toast.LENGTH_SHORT).show();

            //finish();
        }
    }//*/

    private String recuperarCep(){
        CEPSvc cepService = retrofit.create(CEPSvc.class);
        String cep = edtCEP.getText().toString();
        Call<CEP> call = cepService.recuperarCEP(cep);
        call.enqueue(new Callback<CEP>() {
            @Override
            public void onResponse(Call<CEP> call, Response<CEP> response) {
                if(response.isSuccessful()){
                    CEP cep = response.body();
                    endereco = cep.getLogradouro()+" "+cep.getBairro()+" "+cep.getCep();
                    textoResultado.
                            setText(cep.getLogradouro()+"/"+cep.getBairro()+"/"+cep.getLocalidade());
                }
            }

            @Override
            public void onFailure(Call<CEP> call, Throwable t) {

            }
        });
        return endereco;
    }
}