package com.unir.exemploretrofit.model;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.location.LocationListenerCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.unir.exemploretrofit.Permissoes;
import com.unir.exemploretrofit.R;
import com.unir.exemploretrofit.databinding.ActivityMapsBinding;


import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapasAct extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private String [] permissoes = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    private LocationManager locationManager;
    private LocationListener locationListener;
    private String endereco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        //Validar permissões
        Permissoes.validarPermissoes(permissoes, this, 1);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Intent intent = getIntent();
        endereco = intent.getStringExtra("endereco");
        Log.i("endereco",endereco);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        Intent intent = getIntent();
        String endereco = intent.getStringExtra("endereco");

        LatLng posicao= determineLocal(getApplicationContext(),endereco);
        if(posicao != null) {
            mMap.addMarker(new MarkerOptions().position(posicao).title("Seu Endereço por CEP"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(posicao, 16));
        }else{
            Toast.makeText(this, "Endereço invalido", Toast.LENGTH_SHORT).show();
        }

        pedirPermissao();//*/
    }

    public LatLng determineLocal(Context context, String ender){
        LatLng latLng = null;
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        List<Address> geoResults = null;

        try {
            geoResults = geocoder.getFromLocationName(ender, 1);
            while (geoResults.size()==0){
                geoResults = geocoder.getFromLocationName(ender, 1);
            }
            if (geoResults.size()>0){
                Address addr = geoResults.get(0);
                latLng = new LatLng(addr.getLatitude(), addr.getLongitude());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return latLng;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        for (int permissaoResultado : grantResults){
            if(permissaoResultado == PackageManager.PERMISSION_DENIED){
                alertaValidacao();
            }else if (permissaoResultado == PackageManager.PERMISSION_GRANTED){
                pedirPermissao();
            }
        }
    }

    private void pedirPermissao(){
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
           // locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
             //       0,
             //       0,
                //    locationListener);//*/
        }
    }

    private void alertaValidacao(){
        AlertDialog.Builder alerta = new AlertDialog.Builder(getApplicationContext());
        alerta.setTitle("Permissões negadas!");
        alerta.setMessage("Para utilizar o app é necessário aceitar as permissões!");
        alerta.setCancelable(false);
        alerta.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alerta.create().show();
    }

}