package com.example.AppPagamentos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    LinearLayout linearLayout;
    EditText txtValor;
    TextView txtResult;
    Button btTotal, btPagamento;
    CheckBox ckArroz, ckCarne, ckPao, ckLeite, ckOvos;
    RadioButton btSem, bt5, bt10, bt15;
    double total;
    Double desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtResult = findViewById(R.id.txtResult);
        txtValor = findViewById(R.id.txtValorPag);
        btTotal = findViewById(R.id.bttTotal);
        btPagamento = findViewById(R.id.bttPagar);
        ckArroz = findViewById(R.id.chkArroz);
        ckCarne = findViewById(R.id.chkCarne);
        ckLeite = findViewById(R.id.chkLeite);
        ckPao = findViewById(R.id.chkPao);
        ckOvos = findViewById(R.id.chkOvos);
        btSem = findViewById(R.id.bttSemdesc);
        bt5 = findViewById(R.id.btt5);
        bt10 = findViewById(R.id.btt10);
        bt15 = findViewById(R.id.btt15);
        linearLayout = findViewById(R.id.linearLayout);

        btTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total = 0;
                if (ckArroz.isChecked()){total +=3.50;}
                if (ckCarne.isChecked()){total +=12.30;}
                if (ckPao.isChecked()){total +=2.20;}
                if (ckLeite.isChecked()){total += 5.50;}
                if (ckOvos.isChecked()){total += 7.50;}

                if (total <= 0)
                {
                    String valor = "Sua lista de compras está vazia";
                    Toast.makeText(getBaseContext(), valor,Toast.LENGTH_SHORT).show();
                    return;
                }
                else
                {
                String mgs = String.format("\n O valor é $%5.2f", total);
                txtResult.setText(mgs);
                }
            }
        });

        btPagamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (txtValor.getText().toString().equals("")){
                    String val = "Coloque o seu valor";
                    Toast.makeText(getBaseContext(), val,Toast.LENGTH_SHORT).show();
                    return;
                }

                    total = 0;
                    if (ckArroz.isChecked()){total +=3.50;}
                    if (ckCarne.isChecked()){total +=12.30;}
                    if (ckPao.isChecked()){total +=2.20;}
                    if (ckLeite.isChecked()){total += 5.50;}
                    if (ckOvos.isChecked()){total += 7.50;}

                    if (bt5.isChecked()){
                        desc = total-(total*0.05);
                    }else if (bt10.isChecked()){
                        desc = total -(total*0.1);
                    }else if (bt15.isChecked()){
                        desc = total -(total*0.15);
                    } else if (btSem.isChecked()){
                        desc = total;
                    } else{
                        desc = total;
                    }

                double pagClient = Double.parseDouble(txtValor.getText().toString());
                String pgAlert = String.valueOf(pagClient - desc );

                    if (pagClient < desc){
                        AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
                        alerta.setTitle("AVISO");
                        alerta.setMessage("Valor menor que da compra");
                        alerta.setNeutralButton("ok", null);
                        alerta.show();

                    }else {
                        AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
                        alerta.setTitle("AVISO");
                        String dialogo = String.format("seu troco R$ %s \nPreço R$%5.2f",pgAlert,total);
                        alerta.setMessage(dialogo);
                        alerta.setNeutralButton("ok", null);
                        alerta.show();
                    }
            }
        });
    }
}